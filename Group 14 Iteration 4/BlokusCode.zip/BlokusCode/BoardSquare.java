package blokus;
import java.awt.Color;
import javax.swing.*;
import javax.swing.border.Border;

public class BoardSquare extends JPanel
{
private int xcoord, ycoord;			
	
	// constructor takes the x and y coordinates of this square
	public BoardSquare( int xcoord, int ycoord)
	{
		super();
		this.setSize(50,50);
		this.xcoord = xcoord;
		this.ycoord = ycoord;
		this.setBackground(new Color(255,255,255));
		Border border = BorderFactory.createLineBorder(Color.BLACK, 1);
		this.setBorder(border);
	}
	
}
