package blokus;

import blokus.MenuGui;

public class Driver {

	public Driver() {
		
	}

	public static void main(String[] args) {
		MenuGui.main(null);

	}

}
