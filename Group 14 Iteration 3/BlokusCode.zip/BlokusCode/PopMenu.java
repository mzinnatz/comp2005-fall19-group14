package blokus;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;

public class PopMenu {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PopMenu window = new PopMenu();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PopMenu() {
		initialize();
	}
	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBackground(new Color(240, 240, 240));
		frame.getContentPane().setBackground(new Color(248, 248, 255));
		frame.setBounds(474, 270, 600, 300);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setResizable(false);
		popMenu();
	
	}
	
	private void popMenu() {
		
		
		// BUTTON(S)
		
		
		JButton btnSaveAndQuit = new JButton("Save and Quit");
		btnSaveAndQuit.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnSaveAndQuit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//add code to save the board state into a Text document
				
			}
		});
		btnSaveAndQuit.setBounds(48, 160, 150, 40);
		
		JButton btnQuitNoSave = new JButton("Quit Without Saving");
		btnQuitNoSave.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnQuitNoSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
				
			}
		});
		btnQuitNoSave.setBounds(218, 160, 150, 40);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				
			}
		});
		btnCancel.setBounds(388, 160, 150, 40);
		
		
		// LABEL(S)
		
		
		JLabel lblSure = new JLabel("Are you sure you want to quit the game?");
		lblSure.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblSure.setBounds(153, 75, 500, 42);
		
		
		// Add everything to the frame
		
		
		frame.getContentPane().setLayout(null);
		frame.getContentPane().add(btnSaveAndQuit);
		frame.getContentPane().add(btnQuitNoSave);
		frame.getContentPane().add(btnCancel);
		frame.getContentPane().add(lblSure);
				
			
	}
}