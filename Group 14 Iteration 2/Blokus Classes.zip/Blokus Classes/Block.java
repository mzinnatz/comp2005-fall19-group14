package blokus;

import java.awt.color.*;

public class Block {
	//Instance variables
		
	public Block() {
		
	}

	
	
}
