package blokus;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import blokus.Player;
import blokus.PopMenu;

import java.awt.Font;
import java.awt.Color;

public class MenuGui {
	
	private Player playerStats = new Player();
	
	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MenuGui window = new MenuGui();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MenuGui() {
		initialize();
	}
	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBackground(new Color(240, 240, 240));
		frame.getContentPane().setBackground(new Color(248, 248, 255));
		frame.setBounds(270, 120, 1000, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		mainMenu();
	
	}
	
	private void mainMenu() {
		
	
		// BUTTONS
		
		
		JButton btnStartNew = new JButton("New Game");
		btnStartNew.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnStartNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clearGUI();
				gameSetupGUI();
				
			}
		});
		btnStartNew.setBounds(296, 292, 120, 70);
		
		JButton btnLoad = new JButton("Load Game");
		btnLoad.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnLoad.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// ADD FUNCTIONALITY TO LOAD GAME BUTTON
			}
		});
		btnLoad.setBounds(433, 292, 120, 70);
		
		JButton btnExit = new JButton("Exit");
		btnExit.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setBounds(570, 292, 120, 70);
		
		JButton btnSettings = new JButton("Settings");
		btnSettings.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnSettings.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clearGUI();
				settingsMenu();
			}
		});
		btnSettings.setBounds(880, 10, 95, 45);
		
		
		//LABELS
		
		
		JLabel lblBlokus = new JLabel("Blokus");
		lblBlokus.setFont(new Font("Tahoma", Font.BOLD, 35));
		lblBlokus.setBounds(433, 186, 177, 42);
		
		
		// Add everything to the frame
		
		
		frame.getContentPane().setLayout(null);
		frame.getContentPane().add(btnStartNew);
		frame.getContentPane().add(btnLoad);
		frame.getContentPane().add(btnExit);
		frame.getContentPane().add(btnSettings);
		frame.getContentPane().add(lblBlokus);
		
	}
	
	private void settingsMenu() {
		String[] offOn = {"OFF", "ON"};
		
		
		//BUTTON(S)
		
		
		JButton btnBack = new JButton("Back");
		btnBack.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clearGUI();
				mainMenu();
			}
		});
		btnBack.setBounds(880, 10, 95, 45);
		
		
		// LABEL(S)
		
		
		JLabel lblSettings = new JLabel("Settings");
		lblSettings.setFont(new Font("Tahoma", Font.BOLD, 35));
		lblSettings.setBounds(420, 40, 177, 42);
		
		JLabel lblColorblind = new JLabel("Colorblind:");
		lblColorblind.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblColorblind.setBounds(100, 145, 177, 42);
		
		//Labels that are used to show colorblind functionality for now
		
		JLabel lblColor1 = new JLabel("");
		lblColor1.setBounds(370, 155, 20, 20);
		lblColor1.setOpaque(true);
		lblColor1.setBackground(Color.BLUE);
		
		JLabel lblColor2 = new JLabel("");
		lblColor2.setBounds(390, 155, 20, 20);
		lblColor2.setOpaque(true);
		lblColor2.setBackground(Color.RED);
		
		JLabel lblColor3 = new JLabel("");
		lblColor3.setBounds(410, 155, 20, 20);
		lblColor3.setOpaque(true);
		lblColor3.setBackground(Color.YELLOW);
		
		JLabel lblColor4 = new JLabel("");
		lblColor4.setBounds(430, 155, 20, 20);
		lblColor4.setOpaque(true);
		lblColor4.setBackground(Color.GREEN);
		
		
		// COMBOBOX(S)
		
		
				JComboBox<String> colorblind = new JComboBox<>(offOn);
				colorblind.setFont(new Font("Tahoma", Font.BOLD, 11));
				colorblind.setBounds(260, 150, 100, 30);
				colorblind.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if (colorblind.getSelectedItem() == "ON") {
							lblColor1.setBackground(new Color(0, 146, 146));
							lblColor2.setBackground(new Color(73, 0, 146));
							lblColor3.setBackground(new Color(182, 109, 255));
							lblColor4.setBackground(new Color(219, 209, 0));
						}
						else if (colorblind.getSelectedItem() == "OFF") {
							lblColor1.setBackground(Color.BLUE);
							lblColor2.setBackground(Color.RED);
							lblColor3.setBackground(Color.YELLOW);
							lblColor4.setBackground(Color.GREEN);
						}
					}
				});
		
		
		// Add everything to the frame
		
		
		frame.getContentPane().add(colorblind);
		frame.getContentPane().add(lblSettings);
		frame.getContentPane().add(lblColorblind);
		frame.getContentPane().add(btnBack);
		frame.getContentPane().add(lblColor1);
		frame.getContentPane().add(lblColor2);
		frame.getContentPane().add(lblColor3);
		frame.getContentPane().add(lblColor4);
	}
	
	private void gameSetupGUI() {
		String[] numOfPlayers = {"", "2", "3", "4"};
		String[] difficultyStr = {"", "Easy", "Medium", "Hard"};
		
		
		// BUTTON(S)
		
		
		JButton btnStart = new JButton("Start");
		btnStart.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnStart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clearGUI();
				gameGUI();
			}
		});
		btnStart.setBounds(450, 450, 120, 70);
		
		JButton btnCancelStart = new JButton("Cancel");
		btnCancelStart.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnCancelStart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clearGUI();
				mainMenu();
			}
		});
		btnCancelStart.setBounds(880, 10, 95, 45);
		
		
		// COMBOBOX(S)
		
		
		JComboBox<String> players = new JComboBox<>(numOfPlayers);
		players.setFont(new Font("Tahoma", Font.BOLD, 11));
		players.setBounds(550, 80, 100, 30);
		players.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (players.getSelectedItem() == "2")
					playerStats.setNumberOf(2);
				else if (players.getSelectedItem()== "3")
					playerStats.setNumberOf(3);
				else if (players.getSelectedItem() == "4")
					playerStats.setNumberOf(4);
			}
		});
		
		JComboBox<String> difficulty = new JComboBox<>(difficultyStr);
		difficulty.setFont(new Font("Tahoma", Font.BOLD, 11));
		difficulty.setBounds(550, 160, 100, 30);
		difficulty.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (difficulty.getSelectedItem() == "Easy")
					playerStats.setDifficulty("Easy");
				else if (difficulty.getSelectedItem() == "Medium")
					playerStats.setDifficulty("Medium");
				else if (difficulty.getSelectedItem() == "Hard")
					playerStats.setDifficulty("Hard");
			}
		});
		
		
		
		// LABEL(S)
		
		
		JLabel lblPlayers = new JLabel("Number of Players:");
		lblPlayers.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblPlayers.setBounds(360, 72, 177, 42);
		
		JLabel lblDifficulty = new JLabel("Difficulty:");
		lblDifficulty.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblDifficulty.setBounds(360, 152, 177, 42);
		
		
		// Add everything to the frame
		
		
		frame.getContentPane().add(players);
		frame.getContentPane().add(difficulty);
		frame.getContentPane().add(lblPlayers);
		frame.getContentPane().add(lblDifficulty);
		frame.getContentPane().add(btnCancelStart);
		frame.getContentPane().add(btnStart);
	}
	
	private void gameGUI() {
		
		
		// BUTTON(S)
		
		
		JButton btnSaveGame = new JButton("Save Game");
		btnSaveGame.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnSaveGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// SHOW THE USER THE GAME IS SAVED WITH OK POP-UP
			}
		});
		btnSaveGame.setBounds(10, 510, 95, 45);
		
		JButton btnHint = new JButton("Hint");
		btnHint.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnHint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// GIVE THE USER A HINT (MAYBE SO MANY PER GAME)
			}
		});
		btnHint.setBounds(120, 510, 95, 45);
		
		JButton btnQuitGame = new JButton("Quit Game");
		btnQuitGame.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnQuitGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				quitPopup();
			}
		});
		btnQuitGame.setBounds(882, 510, 95, 45);
		
		
		// LABEL(S)
		
		
		JLabel lblplayerStats = new JLabel("Number of Players: " + playerStats.getNumberOf());
		lblplayerStats.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblplayerStats.setBounds(360, 500, 177, 42);
		
		JLabel lblPlayerDiff = new JLabel("Player Difficulty: " + playerStats.getDifficulty());
		lblPlayerDiff.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblPlayerDiff.setBounds(360, 525, 177, 42);
		
		JLabel lblGameBoard = new JLabel("GAMEBOARD", SwingConstants.CENTER);
		lblGameBoard.setBounds(10, 10, 965, 490);
		lblGameBoard.setOpaque(true);
		lblGameBoard.setBackground(new Color(255, 255, 230));
		
		
		// Add everything to the frame
		
		
		frame.getContentPane().add(lblPlayerDiff);
		frame.getContentPane().add(lblGameBoard);
		frame.getContentPane().add(lblplayerStats);
		frame.getContentPane().add(btnSaveGame);
		frame.getContentPane().add(btnHint);
		frame.getContentPane().add(btnQuitGame);
		
	}
	
	private void clearGUI() {
		frame.getContentPane().removeAll();
		frame.revalidate();
		frame.repaint();
	}
	
	private void quitPopup() {
		PopMenu.main(null);
	}
}
