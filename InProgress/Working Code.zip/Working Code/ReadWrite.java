package blokus;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
 
public class ReadWrite {
 
	public void main(ArrayList<String> list) {
		
		final String FNAME = "test.txt";
		
		try ( BufferedWriter bw = 
				new BufferedWriter (new FileWriter (FNAME)) ) 
		{			
			for (String line : list) {
				bw.write (line + "\n");
			}
			
			bw.close ();
			
		} catch (IOException e) {
			e.printStackTrace ();
		}
	}
 
}