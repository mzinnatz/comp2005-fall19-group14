package blokus;

import java.awt.EventQueue;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;

import blokus.Player;
import blokus.PopMenu;
import blokus.Block;

public class MenuGui {
	
	private Player playerStats = new Player();
	Block block = new Block();
	
	private JFrame frame;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MenuGui window = new MenuGui();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	/**
	 * Create the application.
	 */
	public MenuGui() {
		initialize();
	}
	
	/**
	 * Initialize the contents of the frame.
	 */
	
	private void initialize() {
		frame = new JFrame();
		frame.setBackground(new Color(240, 240, 240));
		frame.getContentPane().setBackground(new Color(248, 248, 255));
		frame.setBounds(270, 120, 1000, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.setLayout(null);
		mainMenu();
	
	}
	
	private void mainMenu() {
	
		
		// BUTTONS
		
		
		JButton btnStartNew = new JButton("New Game");
		btnStartNew.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnStartNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clearGUI();
				gameSetupGUI();
				
			}
		});
		btnStartNew.setBounds(296, 292, 120, 70);
		
		JButton btnLoad = new JButton("Load Game");
		btnLoad.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnLoad.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// ADD FUNCTIONALITY TO LOAD GAME BUTTON FROM SAVE FILE
				clearGUI();
				gameGUI();
			}
		});
		btnLoad.setBounds(433, 292, 120, 70);
		
		JButton btnExit = new JButton("Exit");
		btnExit.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setBounds(570, 292, 120, 70);
		
		JButton btnSettings = new JButton("Settings");
		btnSettings.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnSettings.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clearGUI();
				settingsMenu();
			}
		});
		btnSettings.setBounds(880, 10, 95, 45);
		
		
		//LABELS
		
		
		JLabel lblBlokus = new JLabel("Blokus");
		lblBlokus.setFont(new Font("Tahoma", Font.BOLD, 35));
		lblBlokus.setBounds(433, 186, 177, 42);
		
		
		// Add everything to the frame
		
		
		frame.getContentPane().add(btnStartNew);
		frame.getContentPane().add(btnLoad);
		frame.getContentPane().add(btnExit);
		frame.getContentPane().add(btnSettings);
		frame.getContentPane().add(lblBlokus);
		
	}
	
	private void settingsMenu() {
		String[] offOn = {"OFF", "ON"};
		
		
		//BUTTON(S)
		
		
		JButton btnBack = new JButton("Back");
		btnBack.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnBack.setBackground(new Color(255,255,255));
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clearGUI();
				mainMenu();
			}
		});
		btnBack.setBounds(880, 10, 95, 45);
		
		
		// LABEL(S)
		
		
		JLabel lblSettings = new JLabel("Settings");
		lblSettings.setFont(new Font("Tahoma", Font.BOLD, 35));
		lblSettings.setBounds(420, 40, 177, 42);
		
		JLabel lblColorblind = new JLabel("Colorblind:");
		lblColorblind.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblColorblind.setBounds(100, 145, 177, 42);
		
		//Labels that are used to show colorblind setting in settingsMenu.
		
		JLabel lblColor1 = new JLabel("");
		lblColor1.setBounds(370, 155, 20, 20);
		lblColor1.setOpaque(true);
		lblColor1.setBackground(Color.BLUE);
		
		JLabel lblColor2 = new JLabel("");
		lblColor2.setBounds(390, 155, 20, 20);
		lblColor2.setOpaque(true);
		lblColor2.setBackground(Color.RED);
		
		JLabel lblColor3 = new JLabel("");
		lblColor3.setBounds(410, 155, 20, 20);
		lblColor3.setOpaque(true);
		lblColor3.setBackground(Color.YELLOW);
		
		JLabel lblColor4 = new JLabel("");
		lblColor4.setBounds(430, 155, 20, 20);
		lblColor4.setOpaque(true);
		lblColor4.setBackground(Color.GREEN);
		
		
		// COMBOBOX(S)
		
		
		JComboBox<String> colorblind = new JComboBox<>(offOn);
		colorblind.setFont(new Font("Tahoma", Font.BOLD, 11));
		colorblind.setBounds(260, 150, 100, 30);
		colorblind.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (colorblind.getSelectedItem() == "ON") {
					block.setColorBlind(true);
					lblColor1.setBackground(new Color(0, 146, 146));
					lblColor2.setBackground(new Color(73, 0, 146));
					lblColor3.setBackground(new Color(182, 109, 255));
					lblColor4.setBackground(new Color(219, 209, 0));
				}
				else if (colorblind.getSelectedItem() == "OFF") {
					block.setColorBlind(false);
					lblColor1.setBackground(Color.BLUE);
					lblColor2.setBackground(Color.RED);
					lblColor3.setBackground(Color.YELLOW);
					lblColor4.setBackground(Color.GREEN);
				}
			}
		});
		
		
		// COMBOBOX ARROWS
		
		
		
		
		
		// Add everything to the frame
		
		
		frame.getContentPane().add(colorblind);
		frame.getContentPane().add(lblSettings);
		frame.getContentPane().add(lblColorblind);
		frame.getContentPane().add(btnBack);
		frame.getContentPane().add(lblColor1);
		frame.getContentPane().add(lblColor2);
		frame.getContentPane().add(lblColor3);
		frame.getContentPane().add(lblColor4);
	}
	
	private void gameSetupGUI() {
		String[] numOfPlayers = {"Select", "2", "3", "4"};
		String[] difficultyStr = {"Select", "Easy", "Medium", "Hard"};
		
		
		// BUTTON(S)
		
		
		JButton btnStart = new JButton("Start");
		btnStart.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnStart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clearGUI();
				gameGUI();
			}
		});
		btnStart.setBounds(450, 450, 120, 70);
		
		JButton btnCancelStart = new JButton("Cancel");
		btnCancelStart.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnCancelStart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clearGUI();
				mainMenu();
			}
		});
		btnCancelStart.setBounds(880, 10, 95, 45);
		
		
		// COMBOBOX(S)
		
		
		JComboBox<String> players = new JComboBox<>(numOfPlayers);
		players.setFont(new Font("Tahoma", Font.BOLD, 11));
		players.setBackground(new Color(255, 255, 255));
		players.setBounds(550, 80, 100, 30);
		players.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (players.getSelectedItem() == "2")
					playerStats.setNumberOf(2);
				else if (players.getSelectedItem()== "3")
					playerStats.setNumberOf(3);
				else if (players.getSelectedItem() == "4")
					playerStats.setNumberOf(4);
			}
		});
		
		JComboBox<String> difficulty = new JComboBox<>(difficultyStr);
		difficulty.setFont(new Font("Tahoma", Font.BOLD, 11));
		difficulty.setBackground(new Color(255, 255, 255));
		difficulty.setBounds(550, 160, 100, 30);
		difficulty.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (difficulty.getSelectedItem() == "Easy")
					playerStats.setDifficulty("Easy");
				else if (difficulty.getSelectedItem() == "Medium")
					playerStats.setDifficulty("Medium");
				else if (difficulty.getSelectedItem() == "Hard")
					playerStats.setDifficulty("Hard");
			}
		});
		
		
		
		// LABEL(S)
		
		
		JLabel lblPlayers = new JLabel("Number of Players:");
		lblPlayers.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblPlayers.setBounds(360, 72, 177, 42);
		
		JLabel lblDifficulty = new JLabel("Difficulty:");
		lblDifficulty.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblDifficulty.setBounds(360, 152, 177, 42);
		
		
		// Add everything to the frame
		
		
		frame.getContentPane().add(players);
		frame.getContentPane().add(difficulty);
		frame.getContentPane().add(lblPlayers);
		frame.getContentPane().add(lblDifficulty);
		frame.getContentPane().add(btnCancelStart);
		frame.getContentPane().add(btnStart);
	}
	
	private void gameGUI() {
		int x,y;
		x = 20;
		y = 20;
		
		
		// BUTTON(S)
		
		
		JButton btnSaveGame = new JButton("Save Game");
		btnSaveGame.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnSaveGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// ADD FUNCTIONALITY TO SAVE THE GAME HERE
				savePopup();
			}
		});
		btnSaveGame.setPreferredSize(new Dimension(100,45));
		
		JButton btnHint = new JButton("Hint");
		btnHint.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnHint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// GIVE THE USER A HINT (MAYBE SO MANY PER GAME)
			}
		});
		btnHint.setPreferredSize(new Dimension(100,45));
		
		JButton btnQuitGame = new JButton("Leave Game");
		btnQuitGame.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnQuitGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// ADD CODE TO SAVE THE GAME HERE
				clearGUI();
				mainMenu();
				savePopup();
			}
		});
		btnQuitGame.setPreferredSize(new Dimension(100,45));
		
		
		// LABEL(S)
		
		
		JLabel lblplayerStats = new JLabel("Number of Players: " + playerStats.getNumberOf());
		lblplayerStats.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblplayerStats.setBounds(360, 500, 177, 42);
		
		JLabel lblPlayerDiff = new JLabel("Player Difficulty: " + playerStats.getDifficulty());
		lblPlayerDiff.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblPlayerDiff.setBounds(360, 525, 177, 42);
		
		
		// PLAYER AREAS
		
		
		JLabel playerOne = new JLabel("");
		if(block.isColorBlind()) {
			Border borderOne = BorderFactory.createLineBorder(new Color(0, 146, 146), 5);
			playerOne.setBorder(borderOne);
		}
		else {
			Border borderOne = BorderFactory.createLineBorder(Color.RED, 5);
			playerOne.setBorder(borderOne);
		}
		playerOne.setPreferredSize(new Dimension(250,250));
		
		JLabel playerTwo = new JLabel("");
		if(block.isColorBlind()) {
			Border borderTwo = BorderFactory.createLineBorder(new Color(73, 0, 146), 5);
			playerTwo.setBorder(borderTwo);
		}
		else {
			Border borderTwo = BorderFactory.createLineBorder(Color.YELLOW, 5);
			playerTwo.setBorder(borderTwo);
		}
		playerTwo.setPreferredSize(new Dimension(250,250));
		
		JLabel playerThree = new JLabel("");
		if(block.isColorBlind()) {
			Border borderThree = BorderFactory.createLineBorder(new Color(182, 109, 255), 5);
			playerThree.setBorder(borderThree);
		}
		else {
			Border borderThree = BorderFactory.createLineBorder(Color.GREEN, 5);
			playerThree.setBorder(borderThree);
		}
		playerThree.setPreferredSize(new Dimension(250,250));
		
		JLabel playerFour = new JLabel("");
		if(block.isColorBlind()) {
			Border borderFour = BorderFactory.createLineBorder(new Color(219, 209, 0), 5);
			playerFour.setBorder(borderFour);
		}
		else {
			Border borderFour = BorderFactory.createLineBorder(Color.BLUE, 5);
			playerFour.setBorder(borderFour);
		}
		playerFour.setPreferredSize(new Dimension(250,250));
		
			
		// Add everything to the appropriate panel
		
		
		JPanel gamePanel = new JPanel();
		gamePanel.setLayout(new GridLayout(x,y));
		gamePanel.setSize(500,500);
		JPanel leftPanel = new JPanel();
		leftPanel.setLayout(new BorderLayout());
		leftPanel.add(playerFour, BorderLayout.NORTH);
		leftPanel.add(playerThree, BorderLayout.SOUTH);
		leftPanel.setPreferredSize(new Dimension(250, 0));
		JPanel rightPanel = new JPanel();
		rightPanel.setLayout(new BorderLayout());
		rightPanel.add(playerTwo, BorderLayout.NORTH);
		rightPanel.add(playerOne, BorderLayout.SOUTH);
		rightPanel.setPreferredSize(new Dimension(250,0));
		JPanel bottomPanel = new JPanel();
		bottomPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 172, 5));
		bottomPanel.setPreferredSize(new Dimension(0, 55));
		bottomPanel.add(btnSaveGame);
		bottomPanel.add(btnHint);
		bottomPanel.add(btnQuitGame);
		frame.setLayout(new BorderLayout());
		frame.add(gamePanel, BorderLayout.CENTER);
		frame.add(leftPanel, BorderLayout.WEST);
		frame.add(rightPanel, BorderLayout.EAST);
		frame.add(bottomPanel, BorderLayout.SOUTH);
		
		
		// BOARD
		
				
		BoardSquare [][] gridSquares;
		gridSquares = new BoardSquare [x][y];
		for (int column = 0; column < x; column ++) {
			for (int row = 0; row < y; row ++) {
				gridSquares [column][row] = new BoardSquare(x,y);
				gridSquares [column][row].setSize(20,20);
				gamePanel.add(gridSquares[column][row]);
			}
		}
				
		frame.setVisible(true);
	}
	
	private void clearGUI() {
		frame.getContentPane().removeAll();
		frame.revalidate();
		frame.repaint();
	}
	
	private void savePopup() {
		PopMenu.main(null);
	}
}
